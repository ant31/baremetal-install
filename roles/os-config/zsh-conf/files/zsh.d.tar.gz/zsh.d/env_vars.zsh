export DEBEMAIL=2t.antoine@gmail.com
export DEBFULLNAME=Antoine Legrand


export FANCY_FORMAT=name,state,ipv4,ipv6,memory,ram,swap,autostart
