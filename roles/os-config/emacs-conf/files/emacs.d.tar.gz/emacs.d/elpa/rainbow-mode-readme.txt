This minor mode sets background color to strings that match color
names, e.g. #0000ff is displayed in white with a blue background.